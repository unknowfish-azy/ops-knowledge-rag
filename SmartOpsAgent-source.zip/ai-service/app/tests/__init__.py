"""
AI Service tests.
"""